package com.google.gwt.gin.higherlower.client;

import com.google.gwt.user.client.ui.Composite;

/**
 * @author Robbie Vanbrabant
 */
public abstract class Homepage extends Composite {

}

package com.google.gwt.gin.higherlower.client;

/**
 * Result of a card guess.
 */
public enum PlayerGuessResult {
  RIGHT, WRONG
}
